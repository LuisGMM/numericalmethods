


class InadequateArgsCombination(Exception):
    pass
