# CharliePY
This package aims to give the typical UC3M (Universidad Carlos III de Madrid) the main resources to make experiment reports, numerical labs, numerical methods assignments, etc.

![Tests](https://github.com/LuisGMM/CharliePY/actions/workflows/tests.yml/badge.svg)